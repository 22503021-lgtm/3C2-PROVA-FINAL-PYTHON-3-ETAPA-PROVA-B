import streamlit as st
import pandas as pd
import plotly.express as px
import os

st.set_page_config(
    page_title="Dados transporte BH",
    page_icon="🚌",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🚍 Dados transporte BH")
st.caption(
    "Painel baseado na Tabela Dados transporte BH"
)

ARQUIVO_PADRAO = "dados_transporte_bh.csv"
ABA_DADOS = "BR GR UF MU"

MODAIS = [
    "A pé",
    "Bicicleta",
    "Motocicleta ou Mototaxi",
    "Automóvel, taxi ou assemelhados",
    "Transporte coletivo",
    "Outros",
]
RACAS = ["Branca", "Preta ou Parda", "Indígena"]
COLUNAS = {
    "Branca": MODAIS,
    "Preta ou Parda": MODAIS,
    "Indígena": MODAIS,
}
REGIOES = ["Norte", "Nordeste", "Sudeste", "Sul", "Centro-oeste"]
UFS = [
    "Rondônia", "Acre", "Amazonas", "Roraima", "Pará", "Amapá", "Tocantins",
    "Maranhão", "Piauí", "Ceará", "Rio Grande do Norte", "Paraíba",
    "Pernambuco", "Alagoas", "Sergipe", "Bahia", "Minas Gerais",
    "Espírito Santo", "Rio de Janeiro", "São Paulo", "Paraná",
    "Santa Catarina", "Rio Grande do Sul", "Mato Grosso do Sul",
    "Mato Grosso", "Goiás", "Distrito Federal"
]
NIVEIS = ["Brasil e Regiões", "Unidades da Federação", "Municípios", "Todos"]

@st.cache_data
def carregar_tabela(arquivo):
    bruto = pd.read_excel('dados_transporte_bh.xlsx', engine='openpyxl')

    dados = bruto.iloc[3:, :19].copy()
    dados = dados.rename(columns={0: "localidade"})
    dados = dados[dados["localidade"].notna()].copy()
    dados["localidade"] = dados["localidade"].astype(str).str.strip()

    registros = []
    for _, linha in dados.iterrows():
        local = linha["localidade"]
        for indice_raca, raca in enumerate(RACAS):
            inicio = 1 + indice_raca * 6
            for indice_modal, modal in enumerate(MODAIS):
                valor = linha.iloc[inicio + indice_modal]
                valor = pd.to_numeric(
                    str(valor).replace(",", ".") if pd.notna(valor) else None,
                    errors="coerce"
                )
                registros.append({
                    "localidade": local,
                    "raca": raca,
                    "meio_transporte": modal,
                    "percentual": valor
                })

    df = pd.DataFrame(registros).dropna(subset=["percentual"])
    df = df[df["percentual"].between(0, 100)].copy()

    def classificar(local):
        if local == "Brasil":
            return "Brasil"
        if local in REGIOES:
            return "Região"
        if local in UFS:
            return "UF"
        return "Município"

    df["nivel"] = df["localidade"].map(classificar)
    return df

st.sidebar.title("📌 Menu e filtros")
arquivo_upload = st.sidebar.file_uploader(
    "📂 Envie a Tabela Dados Transporte BH",
    type=["xlsx", "xls", "csv"]
)

arquivo = arquivo_upload if arquivo_upload is not None else (
    ARQUIVO_PADRAO if os.path.exists(ARQUIVO_PADRAO) else None
)

if arquivo is None:
    st.warning("Envie o arquivo **dados_transporte_bh.csv** na barra lateral para carregar o painel.")
    st.info("O arquivo esperado deve conter a aba **BR GR UF MU**.")
    st.stop()

try:
    df = carregar_tabela(arquivo)
except Exception as erro:
    st.error(f"Não foi possível ler a planilha: {erro}")
    st.stop()

st.sidebar.markdown("---")
nivel = st.sidebar.selectbox("Nível geográfico", NIVEIS, index=0)

if nivel == "Brasil e Regiões":
    locais_disponiveis = ["Brasil"] + REGIOES
    df_filtrado = df[df["nivel"].isin(["Brasil", "Região"])]
elif nivel == "Unidades da Federação":
    locais_disponiveis = sorted(df.loc[df["nivel"] == "UF", "localidade"].unique())
    df_filtrado = df[df["nivel"] == "UF"]
elif nivel == "Municípios":
    locais_disponiveis = sorted(df.loc[df["nivel"] == "Município", "localidade"].unique())
    df_filtrado = df[df["nivel"] == "Município"]
else:
    locais_disponiveis = sorted(df["localidade"].unique())
    df_filtrado = df.copy()

locais_selecionados = st.sidebar.multiselect(
    "Região / UF / Município",
    options=locais_disponiveis,
    default=locais_disponiveis[:min(8, len(locais_disponiveis))]
)
if locais_selecionados:
    df_filtrado = df_filtrado[df_filtrado["localidade"].isin(locais_selecionados)]
else:
    df_filtrado = df_filtrado.iloc[0:0]

racas_selecionadas = st.sidebar.multiselect(
    "Cor ou raça",
    options=RACAS,
    default=RACAS
)
modais_selecionados = st.sidebar.multiselect(
    "Meio de transporte",
    options=MODAIS,
    default=MODAIS
)

df_filtrado = df_filtrado[
    df_filtrado["raca"].isin(racas_selecionadas)
    & df_filtrado["meio_transporte"].isin(modais_selecionados)
]

if df_filtrado.empty:
    st.warning("Nenhum dado corresponde aos filtros selecionados. Altere os filtros na barra lateral.")
    st.stop()

st.subheader("📍 Indicadores do recorte selecionado")
modal_kpi = st.selectbox(
    "Modal usado nos indicadores de mediana",
    options=modais_selecionados if modais_selecionados else MODAIS,
    index=0,
    key="modal_kpi"
)
kpi_df = df_filtrado[df_filtrado["meio_transporte"] == modal_kpi]

k1, k2, k3 = st.columns(3)
for coluna, raca in zip([k1, k2, k3], RACAS):
    valores = kpi_df.loc[kpi_df["raca"] == raca, "percentual"]
    mediana = valores.median() if not valores.empty else float("nan")
    coluna.metric(
        f"Mediana — {raca}",
        f"{mediana:.1f}%" if pd.notna(mediana) else "Sem dados",
        help=f"Mediana dos percentuais das localidades selecionadas para o modal {modal_kpi}."
    )

st.caption(
    "Os percentuais representam a distribuição das mulheres ocupadas por modal, "
    "separada por cor ou raça. As medianas são calculadas entre as localidades filtradas."
)
st.divider()


aba1, aba2, aba3, aba4 = st.tabs([
    "📊 Distribuição por modal",
    "🧬 Comparação por raça",
    "🚲 Mobilidade por bicicleta",
    "📋 Dados e tabela"
])

with aba1:
    st.subheader("Participação percentual por meio de transporte")
    raca_grafico = st.selectbox("Selecione a cor ou raça para o gráfico", racas_selecionadas or RACAS)
    pizza = df_filtrado[df_filtrado["raca"] == raca_grafico].groupby(
        "meio_transporte", as_index=False
    )["percentual"].mean()
    if not pizza.empty:
        fig_pizza = px.pie(
            pizza,
            names="meio_transporte",
            values="percentual",
            hole=0.48,
            title=f"Distribuição dos modais — {raca_grafico}",
        )
        fig_pizza.update_traces(textposition="inside", textinfo="label+percent")
        st.plotly_chart(fig_pizza, use_container_width=True)

    barras = df_filtrado.groupby(
        ["localidade", "raca", "meio_transporte"], as_index=False
    )["percentual"].mean()
    fig_barra = px.bar(
        barras,
        x="localidade",
        y="percentual",
        color="meio_transporte",
        barmode="group",
        facet_row="raca" if len(racas_selecionadas) > 1 else None,
        labels={
            "localidade": "Localidade",
            "percentual": "Percentual (%)",
            "meio_transporte": "Meio de transporte",
            "raca": "Cor ou raça"
        },
        title="Comparação dos meios de transporte nas localidades selecionadas"
    )
    fig_barra.update_layout(xaxis_tickangle=-35)
    st.plotly_chart(fig_barra, use_container_width=True)

with aba2:
    st.subheader("Diferenças entre grupos de cor ou raça")
    box = df_filtrado.copy()
    fig_box = px.box(
        box,
        x="raca",
        y="percentual",
        color="raca",
        points="all",
        facet_col="meio_transporte",
        facet_col_wrap=3,
        labels={"raca": "Cor ou raça", "percentual": "Percentual (%)"},
        title="Distribuição dos percentuais por modal e cor ou raça"
    )
    st.plotly_chart(fig_box, use_container_width=True)

    resumo = df_filtrado.groupby(
        ["meio_transporte", "raca"], as_index=False
    )["percentual"].median().rename(columns={"percentual": "mediana (%)"})
    st.markdown("**Mediana por meio de transporte e cor ou raça**")
    st.dataframe(
        resumo.pivot(index="meio_transporte", columns="raca", values="mediana (%)").round(1),
        use_container_width=True
    )

with aba3:
    st.subheader("Uso de bicicleta por localidade")
    bike = df_filtrado[df_filtrado["meio_transporte"] == "Bicicleta"].copy()
    if not bike.empty:
        fig_bike = px.bar(
            bike.sort_values("percentual", ascending=True),
            x="percentual",
            y="localidade",
            color="raca",
            barmode="group",
            orientation="h",
            labels={
                "percentual": "Mulheres que utilizam bicicleta (%)",
                "localidade": "Localidade",
                "raca": "Cor ou raça"
            },
            title="Percentual que utiliza bicicleta por localidade"
        )
        st.plotly_chart(fig_bike, use_container_width=True)

        ranking = bike.sort_values("percentual", ascending=False).groupby(
            ["raca"], group_keys=False
        ).head(10)
        st.markdown("**Até 10 localidades com maior percentual por grupo**")
        st.dataframe(
            ranking[["raca", "localidade", "percentual"]].rename(
                columns={"raca": "Cor ou raça", "localidade": "Localidade", "percentual": "Bicicleta (%)"}
            ),
            use_container_width=True,
            hide_index=True
        )
    else:
        st.info("Selecione o modal Bicicleta nos filtros da barra lateral para visualizar este gráfico.")

with aba4:
    st.subheader("Tabela tratada com Pandas")
    st.dataframe(
        df_filtrado.rename(columns={
            "localidade": "Localidade",
            "nivel": "Nível geográfico",
            "raca": "Cor ou raça",
            "meio_transporte": "Meio de transporte",
            "percentual": "Percentual (%)"
        }),
        use_container_width=True,
        hide_index=True
    )
    csv = df_filtrado.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "⬇️ Baixar dados filtrados (CSV)",
        data=csv,
        file_name="dados_transporte_bh.csv",
        mime="text/csv"
    )


st.divider()
st.subheader("🧭 Leitura para gestores de mobilidade")
st.markdown(
    """
    - **Transporte coletivo:** permite observar a participação desse modal no deslocamento ao trabalho.
    - **Transporte individual motorizado:** automóvel/táxi e motocicleta/mototáxi.
    - **Mobilidade ativa:** deslocamentos a pé e por bicicleta.
    - **Equidade:** comparar os resultados por cor ou raça ajuda a identificar diferenças no padrão de deslocamento.
    """
)